 
import { Component, Renderer2, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {

  isDarkTheme:boolean = false;

  constructor(private renderer: Renderer2, @Inject(DOCUMENT) private document: Document) {}

  toggleTheme(){
    this.isDarkTheme = !this.isDarkTheme;
    if(this.isDarkTheme){
      this.renderer.addClass(this.document.body, 'dark-theme');
    }else{
      this.renderer.removeClass(this.document.body, 'dark-theme');
    }
  }
}
